# filefinder
python class for searching files on harddrive
