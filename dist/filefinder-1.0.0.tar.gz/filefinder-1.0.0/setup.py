import setuptools

setuptools.setup(
    name='filefinder',
    version='1.0.0',    
    description='python class for searching files on harddrive',
    url='https://github.com/mes21/filefinder',
    author='Tobias Andorfer',
    author_email='tandorfe@gmail.com',
    license='MIT License',
    packages=['filefinder'],
    install_requires=[                    
                      ],

    
)