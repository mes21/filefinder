"""filefinder version module"""

__version__ = "1.0.0"